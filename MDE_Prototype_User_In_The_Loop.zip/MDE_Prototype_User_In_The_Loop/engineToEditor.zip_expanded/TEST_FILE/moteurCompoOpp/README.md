# moteurCompoOppo
opportunistic composition engine
