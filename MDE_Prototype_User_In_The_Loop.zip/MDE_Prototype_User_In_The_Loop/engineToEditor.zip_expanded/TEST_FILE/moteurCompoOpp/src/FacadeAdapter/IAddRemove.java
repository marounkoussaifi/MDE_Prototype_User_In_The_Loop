package FacadeAdapter;
import MockupCompo.*;
import OCPlateforme.OCComponent;


public interface IAddRemove {
	
	public void addComponent(OCComponent component);
	/**
	 * add components 
	 * 
	 * 
	 */
	
	public void removeComponent(OCComponent component);

	
	/**
	 * remove components
	 * 
	 *
	 */
	

}
