package Agent.Agir.GestionBinding;

import OCPlateforme.OCService;

/**
 * Created by Utilisateur on 09/02/2017.
 */
public interface IGestionBinding {
    public void bind(OCService service);
}
