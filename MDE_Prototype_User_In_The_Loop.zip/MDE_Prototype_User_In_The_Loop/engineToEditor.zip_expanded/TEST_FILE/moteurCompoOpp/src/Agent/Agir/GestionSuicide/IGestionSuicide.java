package Agent.Agir.GestionSuicide;

/**
 * Created by Utilisateur on 09/02/2017.
 */
public interface IGestionSuicide {
    public void suicide();
}
