package Agent.Agir.TraitementDecision;

import Agent.Decider.ComposantCreationDecision.AbstractDecision;

/**
 * Created by Utilisateur on 10/02/2017.
 */
public interface ITraitementDecision {
    public void traiter(AbstractDecision decision);
}
