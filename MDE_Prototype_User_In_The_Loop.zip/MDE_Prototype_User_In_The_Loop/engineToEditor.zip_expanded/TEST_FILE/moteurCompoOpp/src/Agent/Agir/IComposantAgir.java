package Agent.Agir;

/**
 * Created by Utilisateur on 10/02/2017.
 */
public interface IComposantAgir {
    public void agir();
}
