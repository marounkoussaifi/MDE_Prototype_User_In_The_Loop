package Agent.Agir.GenererMessage;

import com.m2dl.sma.infrastructure.agent.ReferenceAgent;

/**
 * Created by Utilisateur on 09/02/2017.
 */
public interface IGenererMessage {
    public void genererMessage(String type, ReferenceAgent to);
}
