package Agent.Percevoir.CreerPerception.Perceptions;

import Agent.Percevoir.CreerPerception.Perceptions.AbstractPerception;

/**
 * Created by Kévin on 10/02/2017.
 */
public class PerceptionVide extends AbstractPerception {
	public PerceptionVide(Object message) {

	}
}