package Agent.Percevoir.CreerPerception.Perceptions;

/**
 * Created by Kévin on 10/02/2017.
 */
public abstract class AbstractPerception {
}
