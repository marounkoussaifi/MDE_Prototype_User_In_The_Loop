package Agent.Decider.ComposantTraitementReponse;

import Agent.Decider.ComposantCreationDecision.AbstractDecision;
import Agent.Decider.ComposantCreationDecision.DecisionGenererMessage;
import Agent.Percevoir.CreerPerception.Perceptions.PerceptionReponse;

import java.util.List;

/**
 * Created by qsaieb on 10/02/2017.
 */
public class TraitementReponse implements ITraitementReponse {

	@Override
	public AbstractDecision traiter(List<PerceptionReponse> listePerceptionReponse) {
		return new DecisionGenererMessage("REPONSE");
	}
}
