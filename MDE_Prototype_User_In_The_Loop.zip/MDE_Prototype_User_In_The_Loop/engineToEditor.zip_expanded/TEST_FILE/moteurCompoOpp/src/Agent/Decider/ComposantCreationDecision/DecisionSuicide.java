package Agent.Decider.ComposantCreationDecision;

/**
 * Created by qsaieb on 10/02/2017.
 */
public class DecisionSuicide extends AbstractDecision {

}
