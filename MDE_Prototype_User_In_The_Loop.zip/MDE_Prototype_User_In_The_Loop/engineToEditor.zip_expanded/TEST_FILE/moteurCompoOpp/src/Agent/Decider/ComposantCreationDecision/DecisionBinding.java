package Agent.Decider.ComposantCreationDecision;

import OCPlateforme.OCService;

/**
 * Created by qsaieb on 10/02/2017.
 */
public class DecisionBinding extends AbstractDecision {
	private OCService service;
	
	public OCService getService() {
		return service;
	}
}
