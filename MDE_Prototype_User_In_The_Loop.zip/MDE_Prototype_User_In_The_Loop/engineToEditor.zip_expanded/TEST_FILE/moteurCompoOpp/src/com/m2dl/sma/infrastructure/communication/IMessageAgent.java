package com.m2dl.sma.infrastructure.communication;

import com.m2dl.sma.infrastructure.agent.ReferenceAgent;

public interface IMessageAgent {

    ReferenceAgent getExpediteur();
}
