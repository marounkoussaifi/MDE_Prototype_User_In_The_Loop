package com.m2dl.sma.infrastructure;

public enum EnumVitesse {
    DIX, VINGT_CINQ, CINQUANTE, SOIXANTE_QUINZE, CENT
}
