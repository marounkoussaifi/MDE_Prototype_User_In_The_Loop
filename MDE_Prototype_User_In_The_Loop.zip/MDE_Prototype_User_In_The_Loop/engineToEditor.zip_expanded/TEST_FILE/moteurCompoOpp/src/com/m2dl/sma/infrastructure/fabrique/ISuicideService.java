package com.m2dl.sma.infrastructure.fabrique;

import com.m2dl.sma.infrastructure.agent.ReferenceAgent;

public interface ISuicideService {

	void seSuicider(ReferenceAgent referenceAgent);
}
