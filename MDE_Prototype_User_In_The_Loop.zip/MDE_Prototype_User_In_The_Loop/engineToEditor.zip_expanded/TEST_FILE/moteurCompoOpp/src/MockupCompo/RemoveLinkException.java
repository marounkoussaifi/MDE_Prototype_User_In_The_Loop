package MockupCompo;
public class RemoveLinkException extends Exception {

}
