package MockupCompo;

public class AddLinkException extends Exception {

}
