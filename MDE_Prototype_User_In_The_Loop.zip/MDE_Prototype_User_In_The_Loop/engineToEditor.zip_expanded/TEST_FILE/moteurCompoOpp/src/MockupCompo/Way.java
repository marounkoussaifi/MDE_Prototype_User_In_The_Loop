package MockupCompo;
public enum Way {
	PROVIDED, REQUIRED;
}
