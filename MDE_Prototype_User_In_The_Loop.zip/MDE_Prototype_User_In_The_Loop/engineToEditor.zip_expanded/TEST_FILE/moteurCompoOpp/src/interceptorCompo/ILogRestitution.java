package interceptorCompo;

import java.io.File;

public interface ILogRestitution {
	/**
	 * Retourne le fichier contenant les différentes connexions
	 */
	File getLogFile();
}
