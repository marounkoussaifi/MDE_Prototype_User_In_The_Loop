package Test;

import com.m2dl.sma.infrastructure.agent.ReferenceAgent;
import com.m2dl.sma.infrastructure.communication.IMessageAgent;



public class MessageAgentTest implements IMessageAgent {
	
	    public ReferenceAgent getExpediteur() {
	        return null;
	    }
}
